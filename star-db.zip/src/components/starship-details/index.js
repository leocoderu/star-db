import StarshipDetails from './starship-details';
export default StarshipDetails;