import React, {Component} from "react";
import SwapiService from "../../services/swapi-service";
import Spinner from "../spinner/spinner";
import ErrorButton from "../error-button";

import "./item-details.css";


export default class ItemDetails extends Component {
    swapiService = new SwapiService();

    state = {
        item: null,
        image: null,
        loading: true
    };

    componentDidMount() {
        this.updateItem();
    }

    componentDidUpdate(prevProps){
        if (this.props.itemId !== prevProps.itemId){
            this.updateItem();
        }
    }

    updateItem() {
        const { itemId, getData, getImageUrl } = this.props;
        if (!itemId) {
            return;
        }

        getData(itemId)
            .then((item) => {
                //console.log("updateItem()", item.name);
                this.setState({ item, image: getImageUrl(item), loading: false });
            });
    }

    render(){

        const content = this.state.loading ? <Spinner /> : <ItemView item = {this.state.item} image={this.state.image}/>;
        //console.log("render()", this.state.item);
        return(
          <div className="item-details card">
              {content}
          </div>
        );
    }
}

const ItemView = ({item, image}) => {
    const {id, name, gender, birthYear, eyeColor} = item;

    //console.log("ItemView image", name);

    return(
        <React.Fragment>
            <img className="item-image"
                src={image}
                alt="item"/>

            <div className="card-body">
                <h4>{name}</h4>
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">
                        <span className="term">Gender</span>
                        <span>{gender}</span>
                    </li>
                    <li className="list-group-item">
                        <span className="term">Birth Year</span>
                        <span>{birthYear}</span>
                    </li>
                    <li className="list-group-item">
                        <span className="term">Eye color</span>
                        <span>{eyeColor}</span>
                    </li>
                </ul>
                <ErrorButton />
            </div>
        </React.Fragment>
    );
}
